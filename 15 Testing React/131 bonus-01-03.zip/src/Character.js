import React from 'react'

export default ({name, side}) => (
  <li>{name} - <strong>{side}</strong></li>
)