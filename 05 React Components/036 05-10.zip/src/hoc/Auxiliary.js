import React from 'react'

const Auxiliary = (props) => {
  return props.children
}

export default Auxiliary