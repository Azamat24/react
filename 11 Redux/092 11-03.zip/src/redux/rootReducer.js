
const initialState = {
  counter: 0
}

export default function rootReducer(state = initialState, action) {
  return state
}