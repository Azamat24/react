import React from 'react'

function App() {
  return (
    <div className="container pt-4">
      <h1>Hello World!</h1>
    </div>
  );
}

export default App;
