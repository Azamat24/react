import React from 'react'

export const About = () => {

  return (
    <div>
      <h1>About page</h1>
    </div>
  )
}
