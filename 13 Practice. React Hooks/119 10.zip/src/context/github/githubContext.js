import {createContext} from 'react'

export const GithubContext = createContext()
