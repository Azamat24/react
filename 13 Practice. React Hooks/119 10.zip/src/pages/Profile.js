import React from 'react'

export const Profile = () => {

  return (
    <div>
      <h1>Profile page</h1>
    </div>
  )
}
